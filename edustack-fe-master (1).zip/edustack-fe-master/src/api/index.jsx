import axios from 'axios';

const baseUrl = 'http://localhost:4000/';

const getAccessToken = () => localStorage.getItem('token');
const setAccessToken = (token) => localStorage.setItem('token', token);

//   and interceptor comes here
const accessToken = getAccessToken();
const platformApi = axios.create({
	baseURL: baseUrl,
	headers: {
		'content-Type': 'application/json'
	}
});
platformApi.interceptors.request.use((config) => {
	const token = getAccessToken();
	if (token) {
		config.headers['Authorization'] = `${token}`;
		// config.headers['Access-Control-Allow-Credentials'] = 'true'
	}
	return config;
});
platformApi.interceptors.response.use(
	(config) => config,
	(error) => {
		if (error) {
			const originalRequest = error.config;
			const API_KEY = 'API_KEY';
			const URL = 'REPLACE_WITH_YOUR_ENDPOINT';
			console.log('error', error);
			const obj = {
			};
			return error;
			// axios
			//   .post(URL, {
			//     headers: {
			//       "content-type": "application/x-www-form-urlencoded"
			//     }
			//   })
			//   .then(res => {
			//     if (res.data.token) {
			//       setAccessToken(res.data.token);
			//       axios.defaults.headers.common["Authorization"] =
			//         "Bearer " + res.data.token;
			//       return axios(originalRequest);
			//     }
			//   });
		} else if (error.response.data.status === 'error') {
			const obj = {
				data: { status_code: 400 }
			};
			return obj;
		}
	}
);
export { platformApi, setAccessToken, baseUrl, getAccessToken };
