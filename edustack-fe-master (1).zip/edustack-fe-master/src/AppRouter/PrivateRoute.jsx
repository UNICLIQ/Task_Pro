import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import Home from '../Pages/Home';


const PrivateRoute = ({ component: Component, loggedIn, ...rest }) => (
  <Route
    {...rest}
    render={props => (localStorage.getItem('token') ? (
      <Home />
    ) : (
      <Redirect
        to={{
          pathname: '/',
          state: { from: props.location },
        }}
      />
    ))
    }
  />
);

export default PrivateRoute;
