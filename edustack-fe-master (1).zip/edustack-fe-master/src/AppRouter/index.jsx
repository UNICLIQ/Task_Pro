import React from 'react';
import { BrowserRouter as Router,Route, Switch } from 'react-router-dom';
import Login from '../Pages/Login';
import SignUp from '../Pages/SignUp';
import PrivateRoute from './PrivateRoute';

const AppRouter = () => {
	return (
		<Router >
			<Switch>
				<Route exact path="/" component={Login} />
        <Route exact path="/register" component={SignUp} />
				<PrivateRoute exact path="/home"/>
			</Switch>
		</Router>
	);
};

export default AppRouter;