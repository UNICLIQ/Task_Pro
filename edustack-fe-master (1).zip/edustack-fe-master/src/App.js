import React from 'react';
import './App.css';
import AppRouter from './AppRouter';
import 'antd/dist/antd.css';
class App extends React.Component {
	render() {
		return (
			<div>
			<AppRouter/>
			</div>
		);
	}
}

export default App;
