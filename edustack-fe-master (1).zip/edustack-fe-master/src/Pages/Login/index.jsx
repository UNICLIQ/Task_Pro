import React,{useEffect} from 'react'
import { Form, Icon, Input, Button, Checkbox, Row, Col, message } from 'antd';
import { platformApi, setAccessToken } from '../../api';
import Logo from "./logo192.png"
import { withRouter } from 'react-router-dom';

const Login = ({ form, history }) => {
  const { getFieldDecorator } = form;

  useEffect(() => {
    if(localStorage.getItem('token')){
      history.push('/home')
    }
  },[])

  const submitData = () => {
    form.validateFields((validationError) => {
      if (validationError === null) {
        platformApi.post('/login', form.getFieldsValue())
          .then(res => {
            let { data } = res;
            if (data.code === 200) {
              setAccessToken(data.response.token)
              history.push('/home')
            }
            else{
              message.error('Credintials Invalid')
            }
          })
      }
    })
  }
  return (
    <Row gutter={16}>
      <Col span={9}></Col>
      <Col span={6} style={{ marginTop: '20vh' }}>
        <div>
          <img style={{ height: '20vh', marginBottom: '20px', alignItems: 'center', marginLeft: '7vw' }} src={Logo} />
        </div>
        <Form className="login-form">
          <Form.Item>
            {getFieldDecorator('username', {
              rules: [{ required: true, message: 'Please input your username!' }],
            })(
              <Input
                prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                placeholder="Username"
              />,
            )}
          </Form.Item>
          <Form.Item>
            {getFieldDecorator('password', {
              rules: [{ required: true, message: 'Please input your Password!' }],
            })(
              <Input
                prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                type="password"
                placeholder="Password"
              />,
            )}
          </Form.Item>
          <Button onClick={() => {
            submitData()
          }}
            type="primary"
            className="login-form-button"
            style={{ width: '100%' }}
          >
            Log in
          </Button>

        </Form>
        <Row style={{ marginTop: '20px' }} type="flex" justify="space-around">
          <Button onClick={() => { history.push('/register') }} type="link">
            Register Now
          </Button>
        </Row>
      </Col>
    </Row>
  )
}

const WrappedNormalLoginForm = Form.create({ name: 'normal_login' })(Login);
export default withRouter(WrappedNormalLoginForm)