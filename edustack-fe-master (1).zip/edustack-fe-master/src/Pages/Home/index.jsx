import React from 'react'
import { useEffect, useState } from 'react'
import { Upload, Icon, message, Row, Col, Select, Button } from 'antd';
import { platformApi } from '../../api';
const { Dragger } = Upload;
const { Option } = Select



const Home = () => {

  const [board, setBoard] = useState(null);
  const [standard, setStandard] = useState(null);
  const [subject, setSubject] = useState(null);
  const [uploaded, setUploaded] = useState(false);
  const [type, setType] = useState(1);
  const [data, setData] = useState(null)

  useEffect(() => {
    platformApi.get('/get')
  }, [])

  const getData = () => {
    platformApi.get('/firstData').then(res => {
      let { data } = res;
      if (data.code === 200) {
        setData(data.response)
        setType(2)
      }
    })
  }

  const updateData = () => {
    platformApi.put('/update', data).then(async (res) => {
      let { data } = res;
      if (data.code === 200) {
        let { response } = data;

        setData(response)
      }
    })
  }

  const props = {
    name: 'file',
    multiple: false,
    action: 'http://localhost:4000/uploadCSV',
    onChange(info) {
      const { status } = info.file;
      if (status !== 'uploading') {
        console.log(info.file, info.fileList);
      }
      if (status === 'done') {
        message.success(`${info.file.name} file uploaded successfully.`);
        setUploaded(true)
      } else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };

  return (
    <div>
      {
        type === 1 &&
        (<Row>
          <Col span={8}></Col>
          <Col span={8} style={{ marginTop: '10vh' }}>
            <h3>Upload Json here :</h3>
            <Dragger {...props}>
              <p className="ant-upload-drag-icon">
                <Icon type="inbox" />
              </p>
              <p className="ant-upload-text">Click or drag file to this area to upload</p>
              <p className="ant-upload-hint">
                Support for a single or bulk upload. Strictly prohibit from uploading company data or other
                band files
           </p>
            </Dragger>
            <Select
              style={{ width: "100%", marginTop: '40px' }}
              placeholder="Select Board"
              onChange={(value) => { setBoard(value) }}
            >
              <Option value="stateBoard">State Board</Option>
              <Option value="centralBoard">Central Board</Option>
            </Select>
            <Select
              style={{ width: "100%", marginTop: '40px' }}
              placeholder="Select Class"
              onChange={(value) => { setStandard(value) }}
            >
              <Option value="10th">10th</Option>
              <Option value="12th">12th</Option>
            </Select>
            <Select
              style={{ width: "100%", marginTop: '40px' }}
              placeholder="Select Subject"
              onChange={(value) => { setSubject(value) }}
            >
              <Option value="maths">Maths</Option>
              <Option value="science">Science</Option>
            </Select>
            <Button style={{ width: '100%', marginTop: '40px' }} type="primary" onClick={() => {
              if (board && standard && subject && uploaded) {
                getData()
              }
            }}>Submit</Button>
          </Col>
        </Row>)
      }
      {
        type === 2 &&
        (<div>
          <Row>
            <Col span={3}></Col>
            <Col span={18}>
              <div style={{ backgroundColor: 'whitesmoke', padding: "0px", margin: '30px', marginTop: '0px' }}>
                <div dangerouslySetInnerHTML={{ __html: JSON.parse(data.question_tag) }} />
                <div style={{ padding: '10px 60px' }} dangerouslySetInnerHTML={{ __html: JSON.parse(data.Answer_tag) }} />
              </div>
            </Col>
          </Row>
          <Row>
            <Col span={8}></Col>
            <Col span={8}>
              <Select
                style={{ width: "100%", marginTop: '40px' }}
                placeholder="Select Topics"
                mode="multiple"
                onChange={(value) => { data.topics = JSON.stringify(value) }}
              >
                <Option value="maths">Maths</Option>
                <Option value="science">Science</Option>
              </Select>
              <Select
                style={{ width: "100%", marginTop: '40px' }}
                placeholder="Select Ratings"
                onChange={(value) => { data.rating = value.toString() }}
              >
                <Option value="1">1</Option>
                <Option value="2">2</Option>
                <Option value="3">3</Option>
                <Option value="4">4</Option>
                <Option value="5">5</Option>
              </Select>
              <Button style={{ width: '100%', marginTop: '40px' }} type="primary" onClick={() => {
                if (data.topics && data.rating) {
                  data.subject = subject;
                  data.board = board;
                  data.standard = standard;
                  data.filled=true
                  updateData()
                }
              }}>Next</Button>
            </Col>
          </Row>
        </div>)
      }
      {/* {
        type===3&&
      } */}

    </div>
  )
}

export default Home
