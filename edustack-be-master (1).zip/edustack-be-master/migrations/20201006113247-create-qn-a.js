'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('QnAs', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      question_tag: {
        type: Sequelize.TEXT
      },
      Answer_tag: {
        type: Sequelize.TEXT
      },
      chapterName: {
        type: Sequelize.STRING
      },
      topics: {
        type: Sequelize.STRING
      },
      rating: {
        type: Sequelize.STRING
      },
      subject: {
        type: Sequelize.STRING
      },
      filled: {
        type: Sequelize.BOOLEAN
      },
      board: {
        type: Sequelize.STRING
      },
      standard: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('QnAs');
  }
};