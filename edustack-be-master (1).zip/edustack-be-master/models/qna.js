'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class QnA extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  QnA.init({
    question_tag: DataTypes.TEXT,
    Answer_tag: DataTypes.TEXT,
    chapterName: DataTypes.STRING,
    topics: DataTypes.STRING,
    rating: DataTypes.STRING,
    subject: DataTypes.STRING,
    filled: DataTypes.BOOLEAN,
    board: DataTypes.STRING,
    standard: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'QnA',
  });
  return QnA;
};