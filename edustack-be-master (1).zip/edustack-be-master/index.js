var express = require('express');
var app = require('express')();
var server = require('http').Server(app);
const jwt = require('jsonwebtoken');
var model = require('./models');
var mime = require('mime');
var path = require('path');
var fs = require('fs');
var parse = require('csv-parse/lib/sync');
var mv = require('mv');
var formidable = require('formidable');
var cors = require('cors');
var bcrypt = require('bcryptjs');
// app.use(express.static(__dirname + '/profile'));

app.use(cors());
app.use(express.json());

app.post('/login', async function(req, res) {
	const { username, password } = req.body;
	let user = await model.Users.findOne({
		where: {
			username: username
		},
		attributes: [ 'username', 'password', 'email' ]
	});
	if (user === null) {
		console.log(user);
		res.json({
			code: 400,
			response: { loggedIn: false }
		});
	} else if (bcrypt.compareSync(password, user.dataValues.password)) {
		var token = jwt.sign({ phone: user.dataValues.phoneNumber }, 'phone', { expiresIn: '30d' });
		res.json({
			code: 200,
			response: { loggedIn: true, username: user.dataValues.username, token: token }
		});
	} else {
		res.json({
			code: 403,
			response: { loggedIn: false }
		});
		console.log(user);
	}
});

app.post('/register', async function(req, res) {
	console.log('object', req.body);
	const { email, username, password, phoneNumber } = req.body;
	try {
		var hash = bcrypt.hashSync(password, 10);
		let users = await model.Users.create({
			email: email,
			username: username,
			password: hash,
			phoneNumber: phoneNumber
		});
		res.send({
			code: 200,
			response: users.dataValues
		});
	} catch (err) {
		res.send({
			code: 500,
			response: err
		});
	}
});

async function upload(data) {
	fs.readFile(data, (err, Data) => {
		if (err) throw err;
		let parsedData = JSON.parse(Data);
		// console.log(parsedData);
		parsedData.map(async (eachData) => {
			let each = await model.QnA.create({
				question_tag: JSON.stringify(eachData.question_tag),
				Answer_tag: JSON.stringify(eachData.answer_tag),
				filled: false
			});
		});
	});
}

async function getData() {
	let details = await model.QnA.findOne({
		where: {
			filled: false
		},
		order: [ [ 'createdAt', 'ASC' ] ]
	});
	return details.dataValues;
}

app.get('/firstData',async function(req,res){
  try{
    let data=await getData()
    res.send({
      code:200,
      response:data
    })
  }
  catch(err){

  }
})

app.put('/update', async function(req, res) {
	try {
    const { topics, chapterName, Answer_tag, question_tag, rating, subject, id,board,standard,filled } = req.body;
    console.log("response",req.body)
		await model.QnA.update({
      where: {
				id: id
			},
      topics,
      question_tag,
      Answer_tag,
      chapterName,
      rating,
      board,
      standard,
      subject,
      filled
		});
		let details = await getData();
		res.send({
			code: 200,
			response: details
		});
	} catch (err) {
		res.send(err);
	}
});

app.post('/uploadCSV', async function(req, res) {
	try {
		const form = new formidable.IncomingForm();
		form.multiples = true;
		form.maxFileSize = 2000 * 1024 * 1024;
		form.parse(req, async (err, fields, files) => {
			var file = files.file;
			let ext = mime.getExtension(file.type);
			const fname = file.name.split('.');
			let fileName = `${fname[0]}.${ext}`;
			const fileUrl = __dirname + `profile/uploads/${fileName}`;
			// Move to new path
			var appDir = path.dirname(require.main.filename);
			mv(
				file.path,
				fileUrl,
				{
					mkdirp: true
				},
				function(err) {
					console.log(err);
				}
			);
			var final;
			final = await upload(fileUrl);
			res.send({
				code: 200
			});
		});
	} catch (err) {
		console.log('error', err);
	}
});

server.listen(4000);
